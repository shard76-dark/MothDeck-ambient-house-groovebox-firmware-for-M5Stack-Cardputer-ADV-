# MothDeck SD pack

Unzip this archive onto the microSD card root. You should end up with a `moth` folder beside this file. Eject the card, boot MothDeck, and on the Instrument page press `R` to rescan.

The built-in drum kit is already **Ambient House** and does not need the card. This pack adds two more kits, a Loops instrument's samples, and a few plugin instruments.

## What is on the card

| Path | What it is |
| --- | --- |
| `moth/drums/808` | 808-style kit. Sine kick, short snare and clap, tight hats |
| `moth/drums/dusty` | The ambient kit with a lowpass, a little noise, and bit reduction |
| `moth/loops/house` | Four one-bar loops at 120 BPM: kick groove, hats, chord, sub |
| `moth/instruments/ep` | Electric piano, one-shot |
| `moth/instruments/reese` | Detuned saw bass with a sub, looping |
| `moth/instruments/saw-lead` | Two detuned saws, looping |
| `moth/instruments/soft-pad` | Slow detuned sines, looping |
| `moth/instruments/house-pluck` | Short decaying pluck, one-shot |
| `moth/instruments/air-bell` | FM bell, one-shot |

## Drums

On the Instrument page, Fn+`,` and Fn+`/` change the kit used by the Drums instrument. The first entry is always the built-in Ambient House kit. The card is not erased or rewritten. If a kit is missing or too big for the internal RAM, the page says so and the built-in kit stays selected.

Keyboard order for every kit, low octave white keys first:

| Key | Pad |
| --- | --- |
| C | Kick |
| C# | Rim |
| D | Snare |
| D# | Clap |
| E | Closed hat |
| F | Open hat |
| F# | Perc |
| G | Tom |
| G# | Shaker |
| A | Ride |
| A# | Snap |
| B | Soft crash |

A kit folder is `mothdeck-kit 1`, a `name=`, and exactly twelve `pad=` lines in that order. Audio is 16-bit PCM WAV. On this board each pad must be at most 6000 frames and the twelve together at most 18000 frames. These files are 16000 Hz and already inside that limit.

## Loops instrument

Assign **Loops** (the row after Pad) to a track. Each note starts one of the audio loops in `/moth/loops`, wrapping if there are fewer loops than keys, and lines the loop up with the current bar. Playback follows the project BPM, so a faster song speeds the loop up. The loops in this pack are one bar at 120 BPM, 8000 Hz, 16000 frames, which is the largest loop the board will load without PSRAM.

The Loops page can still audition and launch a single loop onto a track. That is separate from the Loops instrument, and both use the same cache.

## Plugins

Assign a plugin from the Instrument list with Enter. The folder name is what a song remembers. Files follow `mothdeck-instrument 1` (see the firmware docs). Without PSRAM a plugin sample can be at most 8000 frames. These are 12000 Hz and shorter than that, so they load on the Cardputer ADV.

## Sources and licence

Every WAV in this zip was synthesized by `tools/make_sd_pack.py` and `tools/voices.py` in the MothDeck tree. There are no sampled breaks, no third-party recordings, and no content taken from another project. The pack is MIT, Copyright (c) 2024 MothSynths, the same licence as the firmware.

The public GitHub account `shard76-dark` has no visible repositories, so no looper-project instruments were imported.
