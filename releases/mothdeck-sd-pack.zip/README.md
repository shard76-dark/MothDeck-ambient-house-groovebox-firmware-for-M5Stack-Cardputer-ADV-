# MothDeck SD pack

Unzip this archive onto the microSD card root. You should end up with a `moth` folder beside this file. Eject the card, boot MothDeck, and on the Instrument page press `R` to rescan.

The built-in drum kit is already **Ambient House** and does not need the card. This pack adds two more kits, a Loops instrument's samples, six sample instruments, and six patches (scale, held arp, glide, and the other shortlist sounds).

## What is on the card

| Path | What it is |
| --- | --- |
| `moth/drums/808` | 808-style kit. Sine kick, short snare and clap, tight hats |
| `moth/drums/dusty` | The ambient kit with a lowpass, a little noise, and bit reduction |
| `moth/loops/house` | Four one-bar loops at 120 BPM: kick groove, hats, chord, sub |
| `moth/instruments/ep` | Electric piano, one-shot |
| `moth/instruments/reese` | Detuned saw bass with a sub, looping |
| `moth/instruments/saw-lead` | Two detuned saws, looping |
| `moth/instruments/soft-pad` | Slow detuned sines, looping |
| `moth/instruments/house-pluck` | Short decaying pluck, one-shot |
| `moth/instruments/air-bell` | FM bell, one-shot |
| `moth/instruments/a-minor` | Patch: built-in bass locked to A minor |
| `moth/instruments/held-arp` | Patch: built-in saw, held-note arp |
| `moth/instruments/glide-bass` | Patch: bass plus a saw an octave down, 90 ms glide |
| `moth/instruments/saw-pluck` | Patch: subtractive saw, short envelope, low-pass |
| `moth/instruments/body` | Patch: short pluck sample |
| `moth/instruments/room-drive` | Patch: sine with drive, delay, reverb, and chorus |

## Drums

On the Instrument page, `,` and `/` (or Fn+`,` and Fn+`/`) change the kit used by the Drums instrument. The line under the list shows the kit name. The first entry is always the built-in kit. The card is not erased. If a kit does not fit in free RAM the toast says how many kilobytes it needs and how many are free, and the previous kit stays selected.

Keyboard order for every kit, low octave white keys first:

| Key | Pad |
| --- | --- |
| C | Kick |
| C# | Rim |
| D | Snare |
| D# | Clap |
| E | Closed hat |
| F | Open hat |
| F# | Low tom |
| G | Tom |
| G# | Shaker |
| A | Ride |
| A# | Snap |
| B | Soft crash |

A kit folder is `mothdeck-kit 1`, a `name=`, and exactly twelve `pad=` lines in that order. Audio is unsigned 8-bit mono PCM WAV at 22050 Hz (128 is silence, about 22 KB/s). The speaker mix is still 44100 Hz. A 16-bit mono WAV still loads, and stereo is folded to mono. On this board each pad is kept to 1800 frames and the twelve together to 8000 frames, in internal RAM, after the file is expanded to 16-bit. These files are already inside that limit. The low tom is `perc.wav`. Loops are streamed from the card instead of being copied into RAM.

## Loops instrument

Assign **Loops** (the row after Pad) to a track. Each note starts one of the audio loops in `/moth/loops`, wrapping if there are fewer loops than keys, and lines the loop up with the current bar. Playback follows the project BPM, so a faster song speeds the loop up. The loops in this pack are one bar at 120 BPM, unsigned 8-bit mono, 22050 Hz, 44100 frames (about 44 KB each). They stream from the card in a small window, so the whole file is not kept in RAM.

The Loops page can still audition and launch a single loop onto a track. That is separate from the Loops instrument, and both use the same cache.

## Plugins

Assign a plugin from the Instrument list with Enter. The folder name is what a song remembers. Sample folders follow `mothdeck-instrument 1`. The six patch folders follow `mothdeck-patch 1`: they set a built-in or a short sample plus scale, arp, glide, and the FX rows. On the FX page, Scale, Root, Arp, Glide, Osc2, Blend, and Coarse change those after assign. Without PSRAM a plugin sample can be at most 4096 frames and at most four stay loaded. The sample folders here are unsigned 8-bit mono, 22050 Hz, 3600 frames. `body` is 1800 frames. Both fit on the Cardputer ADV. Patches stay loaded while BLE is on. Loops do not.

## Sources and licence

Every WAV in this zip was synthesized by `tools/make_sd_pack.py` and `tools/voices.py` in the MothDeck tree. There are no sampled breaks, no third-party recordings, and no content taken from another project. The pack is MIT, Copyright (c) 2024 MothSynths, the same licence as the firmware.

The public GitHub account `shard76-dark` has no visible repositories, so no looper-project instruments were imported.
